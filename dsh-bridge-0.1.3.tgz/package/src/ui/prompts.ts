export interface BuiltinCommand {
  name: string;
}

/** 内置命令清单：/plan /compact /feedback /goal 由服务端执行（插件只负责联想与发送）；/clear 为前端命令（本地清空会话）。 */
export const BUILTIN_COMMANDS: BuiltinCommand[] = [
  { name: "/clear" },
  { name: "/plan" },
  { name: "/compact" },
  { name: "/feedback" },
  { name: "/goal" },
];

/** /clear 精确匹配（前端拦截，不发给服务端）。 */
export function isClearCommand(text: string): boolean {
  return text.trim() === "/clear";
}

const MENTION_RE = /@(?:file|folder):([^\s@]+)/g;

/** 提及来源的解析结果：file 为文件内容，folder 为目录树文本。 */
export interface MentionSource {
  kind: "file" | "folder";
  text: string;
}

export function collectMentionPaths(text: string): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(MENTION_RE)) out.push(m[1]);
  return out;
}

export function truncate(text: string, max: number): string {
  if (text.length <= max) return text;
  return text.slice(0, max) + "…";
}

/** 按查询过滤内置命令（query 不带 "/"，如 "com" 匹配 /compact）。 */
export function filterBuiltinCommands(query: string): BuiltinCommand[] {
  const lower = query.toLowerCase();
  return BUILTIN_COMMANDS.filter((c) => c.name.slice(1).startsWith(lower));
}

/** 依据光标前文本解析联想 token（@ 提及 / / 命令）；返回 null 表示无联想。 */
export function matchSuggestToken(before: string): { kind: "mention" | "slash"; query: string } | null {
  const m = before.match(/(?:^|\s)(@(?:file|folder):([^\s@]*)|@([^\s@/]*)|(\/)([^\s@/]*))$/);
  if (!m) return null;
  const kind: "mention" | "slash" = m[1].startsWith("@") ? "mention" : "slash";
  const query = (kind === "mention" ? (m[2] ?? m[3]) : m[5] ?? "").toLowerCase();
  return { kind, query };
}

/** 替换文本中所有出现的标记（String.replace 遇字符串模式只替换首次，同一路径提及多次必须全量替换）。 */
function replaceAll(text: string, search: string, replacement: string): string {
  return text.split(search).join(replacement);
}

/** 把 @file:路径 / @folder:路径 标记替换为内容引用（长内容截断；缺失给出说明）。 */
export async function resolveMentions(
  text: string,
  read: (path: string) => Promise<MentionSource | null>,
  maxChars: number
): Promise<string> {
  let out = text;
  for (const path of collectMentionPaths(text)) {
    const source = await read(path);
    const replacement = source === null
      ? `（找不到 ${path}，请检查路径）`
      : `${source.kind === "file" ? "文件" : "目录"} ${path}：\n> ${truncate(source.text, maxChars).replace(/\n/g, "\n> ")}`;
    out = replaceAll(out, `@file:${path}`, replacement);
    out = replaceAll(out, `@folder:${path}`, replacement);
  }
  return out;
}
